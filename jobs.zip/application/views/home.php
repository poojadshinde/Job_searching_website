<?php $this->load->view('header');?>
<?php $this->load->view('employer/menu');?>









<?php $this->load->view('employer/footer');?>    
<?php $this->load->view('footer');?>


