
<div class="container-fluid employer ">
	<div class="row">
		 <div class="col-12 col-md-4 sidebar-menu " >
				<h2 class="text-white text-center py-4">Find a job you'll love</h2>
				
				<div class="text-center p-4 m-3">
				

				<a href="<?php echo base_url('user/login?type=job_seeker');?>" class="btn btn-blue text-white btn-rounded m-3 px-4">Sign In as Job Seeker</a><br/>
				<a href="<?php echo base_url('user/login?type=employer');?>" class="btn btn-green text-white btn-rounded m-3 px-4">Sign In as Employer</a>
				<a href="<?php echo base_url('user/register');?>" class="btn btn-navy text-white btn-rounded m-3 px-4">Sign UP</a>
					

				

					<img class="img-responsive mx-auto " src="http://pluspng.com/img-png/job-png-hd-jobs-png-pic-png-image-737.png" alt="Chania" width="300">
				
				</div>
			 
		 </div>
		 <div class="col-12 col-md-8">

