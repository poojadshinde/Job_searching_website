
<div class="container-fluid employer">
	<div class="row">
		 <div class="col-12 col-md-3 sidebar-menu" >
		 	<ul>
		 		<li><a href="<?php echo base_url('employer');?>"><i class="fa fa-home mr-2"></i> Home</a></li>
		 		<li><a href="<?php echo base_url('employer/jobs');?>"><i class="fa fa-envelope mr-2"></i>  Jobs</a></li>
		 		<li><a href="<?php echo base_url('employer/candidates');?>"><i class="fa fa-users mr-2"></i>  Find Candidate</a></li>
		 		<li><a href="<?php echo base_url('user/logout');?>"><i class="fa fa-power-off mr-2"></i>  Logout</a></li>
		 	</ul>
		 </div>
		 <div class="col-12 col-md-9">

