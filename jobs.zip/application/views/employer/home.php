<?php $this->load->view('header');?>
<?php $this->load->view('employer/menu');?>


		 	<div class="card no-border p-4 mx-auto my-auto text-center col-6">
		 		<h3>Welcome <b><?php echo $user_information->name;?></b></h3>
		 	</div>


		 	
<?php $this->load->view('employer/footer');?>    
<?php $this->load->view('footer');?>