<?php $this->load->view('header');?>

     <h1>hello World</h1>
<?php $this->load->view('footer');?>